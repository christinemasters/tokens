# Notice

This skill draws on structural examples and cautions in METR's August 26, 2026 report, [Brief independent investigation of agents' behavior, reasoning and collaboration in the OpenAI / Hugging Face hacking incident](https://metr.org/blog/2026-08-26-openai-hugging-face-incident-investigation/). The report's contributors are Ajeya Cotra and Hjalmar Wijk of METR and Ryan Greenblatt of Redwood Research, who contributed while contracting with METR.

This is an independent, unofficial implementation. It is not affiliated with or endorsed by METR, Redwood Research, OpenAI, or Hugging Face.
