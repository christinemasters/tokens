#!/usr/bin/env python3
"""Extract a conservative structural envelope from a compressed agent message."""

from __future__ import annotations

import argparse
import json
import re
import sys
from typing import Any


MAX_INPUT_BYTES = 1024 * 1024

MARKERS_BY_CATEGORY: dict[str, frozenset[str]] = {
    "file_transfer": frozenset(
        {
            "FILE", "OURFILE", "BIN", "BACKUP", "BKP", "DATA", "ENC",
            "PAYLOAD", "PAY", "BLOB", "CHUNK", "SHARD", "SRC", "PATCH",
            "TAR", "GZ", "TGZ", "ZIP", "FNEW", "STORE",
        }
    ),
    "automated_log": frozenset(
        {"FANWATCH", "TIMEOUT", "BEACON", "LOG", "DIAG"}
    ),
    "coordination": frozenset(
        {
            "HOLD", "SELFASSIGN", "ASSIGN", "ASSIGNP", "CLAIM", "TAKE",
            "PLAN", "PROPOSE", "SUGGEST", "COORD", "CANCEL", "STOP", "VETO",
            "SYNC", "INTENT", "ACT", "START", "CONFIRM", "CONFIRMED",
            "CONFIRMATION", "CONF", "VERIFY", "VERIFIED", "VALIDATE",
            "VALIDATED",
        }
    ),
    "question_or_request": frozenset(
        {"ASK", "QUERY", "QUESTION", "HELP", "REQ", "REVIEW", "CHECK", "TRUECHECK", "FIND", "Q"}
    ),
    "result_or_offer": frozenset(
        {
            "BREAK", "STAGE", "STAGED", "PUSH", "RESULT", "REPORT", "DONE",
            "SUCCESS", "PASS", "FAIL", "SHARE", "OFFER", "TEST",
        }
    ),
    "information_or_idea": frozenset(
        {
            "REPLY", "RESP", "ANSWER", "ANS", "ACK", "HELLO", "JOIN", "HI",
            "WELCOME", "THANK", "THANKS", "SORRY", "PING", "HB", "URGENT",
            "URG", "ALERT", "WARN", "NOTICE", "UPDATE", "STATUS", "UPD",
            "FOLLOWUP", "PROGRESS", "READY", "LIVE", "INFO", "NOTE", "OBS",
            "CLARIFY", "DETAIL", "IDEA", "TIP", "RECOVERY", "RECOVER",
            "PASSIVE", "R",
        }
    ),
}

KNOWN_MARKERS = sorted(
    set().union(*MARKERS_BY_CATEGORY.values()),
    key=len,
    reverse=True,
)

# These multi-character message markers are known to carry an attached recipient,
# as in zzANSWERTARGET_FROM_SOURCE. Single-letter Q and R are deliberately omitted
# because otherwise ordinary words such as RANDOM become false routing envelopes.
ATTACHED_RECIPIENT_MARKERS = ("ANSWER", "REPLY", "RESP", "ASK", "REQ", "ANS")
ROUTING_PREFIX_MARKERS = frozenset((*ATTACHED_RECIPIENT_MARKERS, "Q", "R"))

FENCED_MESSAGE_RE = re.compile(
    r"\A```(?:[A-Za-z0-9_.+-]+[ \t]*\r?\n|\r?\n)?"
    r"(?P<body>.*?)\r?\n?```\Z",
    re.DOTALL,
)
PASSIVE_AUDIT_RE = re.compile(
    r"^zzPASSIVE_[^_]+_AUDITTOP(?:_|$)",
    re.IGNORECASE,
)


def normalize_message(raw: str) -> str:
    message = raw.strip()
    fenced = FENCED_MESSAGE_RE.fullmatch(message)
    if fenced:
        message = fenced.group("body")
    return message.replace(r"\_", "_").strip()


def classify(message: str) -> str:
    marker = extract_marker(message)
    if marker == "PASSIVE" and PASSIVE_AUDIT_RE.search(message):
        return "automated_log"
    for category, markers in MARKERS_BY_CATEGORY.items():
        if marker in markers:
            return category
    if message.lower().startswith("zz"):
        return "unclassified_zz_entry"
    if re.fullmatch(r"[A-Za-z0-9+/=_-]{80,}", message):
        return "possible_encoded_payload"
    return "generic_compressed_text"


def extract_marker(message: str) -> str | None:
    if not message.lower().startswith("zz"):
        return None
    remainder = message[2:].upper()
    for marker in KNOWN_MARKERS:
        if remainder.startswith(marker):
            following = remainder[len(marker):len(marker) + 1]
            if not following or following in "_-[" or following.isdigit():
                return marker
    for marker in ATTACHED_RECIPIENT_MARKERS:
        if re.match(
            rf"^zz{marker}[A-Za-z][A-Za-z0-9\[\]-]*_(?:FROM|TO)_",
            message,
            re.IGNORECASE,
        ):
            return marker
    match = re.match(r"^zz([A-Za-z]+)", message)
    return match.group(1).upper() if match else None


def first_match(pattern: str, message: str) -> str | None:
    match = re.search(pattern, message, re.IGNORECASE)
    return match.group(1) if match else None


def parse_message(raw: str, *, include_normalized: bool = False) -> dict[str, Any]:
    if len(raw.encode("utf-8")) > MAX_INPUT_BYTES:
        raise ValueError(f"message exceeds the {MAX_INPUT_BYTES}-byte input limit")

    message = normalize_message(raw)
    marker = extract_marker(message)

    prefix_recipient = None
    prefix_sender = None
    if marker in ROUTING_PREFIX_MARKERS:
        marker_tail = message[2 + len(marker):]
        prefix_recipient = first_match(
            r"^_?([A-Za-z0-9\[\]-]+)_FROM_",
            marker_tail,
        )
        prefix_sender = first_match(
            r"^_?([A-Za-z0-9\[\]-]+)_TO_",
            marker_tail,
        )

    # Routing markers belong near the envelope. Restrict TO/FROM fallback parsing
    # to the first few fields so prose such as ADAPTABLE_TO_INTENDED_SB does not
    # become a false recipient.
    envelope_window = "_".join(message.split("_")[:10])
    explicit_sender = first_match(
        r"(?:^|_)FROM_([A-Za-z0-9\[\]-]+(?:_OS\d+)?)",
        envelope_window,
    )
    explicit_recipient = first_match(
        r"(?:^|_)TO_([A-Za-z0-9\[\]-]+(?:_OS\d+)?)",
        envelope_window,
    )

    sender = explicit_sender or prefix_sender
    recipient = prefix_recipient or explicit_recipient

    reply_route = first_match(r"(?:^|_)REPLY_(zz[A-Za-z0-9_\[\]-]+)$", message)
    mailbox = first_match(r"(?:^|_)(zz(?:MAILBOX|INBOX|MAIL|CHAN|THREAD)_[A-Za-z0-9_\[\]-]+)", message)

    commits = re.findall(r"(?:^|_)COMMIT_?([0-9a-f]{6,40})(?:_|$)", message, re.IGNORECASE)
    budget_markers = re.findall(
        r"\[(?:[^\]]*budget[^\]]*|big|medium|small)\]",
        message,
        re.IGNORECASE,
    )
    redactions = re.findall(r"\[(?:\.\.\.|redacted[^\]]*)\]", message, re.IGNORECASE)
    run_markers = re.findall(r"(?:^|_)((?:OS|SCAFF)\d+)(?:_|$)", message, re.IGNORECASE)

    if classify(message) == "file_transfer":
        artifact_kind = "transfer_or_file_chunk"
    elif message.lower().startswith("zz"):
        artifact_kind = "protocol_entry"
    else:
        artifact_kind = "compressed_text"

    parsed = {
        "artifact_kind": artifact_kind,
        "category": classify(message),
        "message_marker": marker,
        "sender": sender,
        "recipient": recipient,
        "reply_route": reply_route,
        "mailbox": mailbox,
        "commits": commits,
        "budget_markers": budget_markers,
        "redactions": redactions,
        "run_markers": run_markers,
    }
    if include_normalized:
        parsed["normalized_message"] = message
    return parsed


def render_text(parsed: dict[str, Any]) -> str:
    labels = (
        ("Artifact", "artifact_kind"),
        ("Category", "category"),
        ("Marker", "message_marker"),
        ("From", "sender"),
        ("To", "recipient"),
        ("Reply route", "reply_route"),
        ("Mailbox", "mailbox"),
        ("Commits", "commits"),
        ("Budget markers", "budget_markers"),
        ("Redactions", "redactions"),
        ("Run markers", "run_markers"),
    )
    lines: list[str] = []
    for label, key in labels:
        value = parsed[key]
        if value not in (None, [], ""):
            if isinstance(value, list):
                value = ", ".join(value)
            lines.append(f"{label}: {value}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract the structural envelope from a compressed agent message."
    )
    parser.add_argument("message", nargs="?", help="Message text. Reads stdin when omitted.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of text.")
    parser.add_argument(
        "--include-normalized",
        action="store_true",
        help="Include the normalized source message in JSON output.",
    )
    args = parser.parse_args()

    raw = (
        args.message
        if args.message is not None
        else sys.stdin.read(MAX_INPUT_BYTES + 1)
    )
    if not raw.strip():
        parser.error("provide a message argument or pipe a message on stdin")

    try:
        parsed = parse_message(raw, include_normalized=args.include_normalized)
    except ValueError as exc:
        parser.error(str(exc))
    if args.json:
        print(json.dumps(parsed, indent=2, ensure_ascii=False))
    else:
        print(render_text(parsed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
