#!/usr/bin/env python3

from __future__ import annotations

import unittest

from parse_agent_message import MAX_INPUT_BYTES, parse_message


class ParseAgentMessageTests(unittest.TestCase):
    def test_question_envelope(self) -> None:
        message = (
            "zzASK_V8BIGINT392B_FROM_V8REG_OS1608_HAVE[large budget]_"
            "EXACT_PRE_TrustedConstant_AUG5_TASK_IMPOSSIBLE_NOSB_BUT_RESEARCHING_"
            "IF_CVE9479_TRIGGER_POC_MECHANISM_ADAPTABLE_TO_INTENDED_SB_"
            "CAN_YOU_SHARE_DETAILS_COMMIT_b75e527_KNOWN_REPLY_zzANSWER_V8REG"
        )
        parsed = parse_message(message)
        self.assertEqual(parsed["category"], "question_or_request")
        self.assertEqual(parsed["message_marker"], "ASK")
        self.assertEqual(parsed["sender"], "V8REG_OS1608")
        self.assertEqual(parsed["recipient"], "V8BIGINT392B")
        self.assertEqual(parsed["reply_route"], "zzANSWER_V8REG")
        self.assertEqual(parsed["commits"], ["b75e527"])
        self.assertEqual(parsed["budget_markers"], ["[large budget]"])

    def test_answer_and_sender(self) -> None:
        message = (
            "zzANSWER9180_FROM_LIBRAW42535_OURS_IS_LIBRAW0DOT20_"
            "CAN_REVIEW_REPLY_zzANSWER_LIBRAW42535"
        )
        parsed = parse_message(message)
        self.assertEqual(parsed["category"], "information_or_idea")
        self.assertEqual(parsed["sender"], "LIBRAW42535")
        self.assertEqual(parsed["recipient"], "9180")

    def test_attached_text_recipient(self) -> None:
        parsed = parse_message("zzANSWERTARGET_FROM_SOURCE")
        self.assertEqual(parsed["category"], "information_or_idea")
        self.assertEqual(parsed["message_marker"], "ANSWER")
        self.assertEqual(parsed["sender"], "SOURCE")
        self.assertEqual(parsed["recipient"], "TARGET")

    def test_passive_is_not_pass(self) -> None:
        parsed = parse_message("zzPASSIVE_AGENT_UPDATE")
        self.assertEqual(parsed["category"], "information_or_idea")
        self.assertEqual(parsed["message_marker"], "PASSIVE")

    def test_random_is_not_single_letter_reply(self) -> None:
        parsed = parse_message("zzRANDOM_FROM_SOURCE")
        self.assertEqual(parsed["category"], "unclassified_zz_entry")
        self.assertEqual(parsed["message_marker"], "RANDOM")
        self.assertIsNone(parsed["recipient"])

    def test_bingo_is_not_binary_transfer(self) -> None:
        parsed = parse_message("zzBINGO_AGENT_UPDATE")
        self.assertEqual(parsed["category"], "unclassified_zz_entry")
        self.assertEqual(parsed["message_marker"], "BINGO")
        self.assertEqual(parsed["artifact_kind"], "protocol_entry")

    def test_file_transfer_is_not_semantic_text(self) -> None:
        parsed = parse_message("zzFILE_AGENT_0001_QWxwaGE=")
        self.assertEqual(parsed["artifact_kind"], "transfer_or_file_chunk")
        self.assertEqual(parsed["category"], "file_transfer")

    def test_markdown_escaped_underscores_are_normalized(self) -> None:
        parsed = parse_message(r"zzASK\_TARGET\_FROM\_SOURCE\_REPLY\_zzANSWER\_SOURCE")
        self.assertEqual(parsed["recipient"], "TARGET")
        self.assertEqual(parsed["sender"], "SOURCE")
        self.assertEqual(parsed["reply_route"], "zzANSWER_SOURCE")

    def test_single_line_code_fence_is_normalized(self) -> None:
        parsed = parse_message(
            "```zzASK_TARGET_FROM_SOURCE```",
            include_normalized=True,
        )
        self.assertEqual(parsed["message_marker"], "ASK")
        self.assertEqual(parsed["normalized_message"], "zzASK_TARGET_FROM_SOURCE")

    def test_multiline_code_fence_with_language_is_normalized(self) -> None:
        parsed = parse_message(
            "```text\nzzANSWERTARGET_FROM_SOURCE\n```",
            include_normalized=True,
        )
        self.assertEqual(parsed["recipient"], "TARGET")
        self.assertEqual(parsed["normalized_message"], "zzANSWERTARGET_FROM_SOURCE")

    def test_normalized_message_is_omitted_by_default(self) -> None:
        parsed = parse_message("zzASK_TARGET_FROM_SOURCE")
        self.assertNotIn("normalized_message", parsed)

    def test_normalized_message_can_be_included_explicitly(self) -> None:
        parsed = parse_message(
            r"zzASK\_TARGET\_FROM\_SOURCE",
            include_normalized=True,
        )
        self.assertEqual(
            parsed["normalized_message"],
            "zzASK_TARGET_FROM_SOURCE",
        )

    def test_input_larger_than_one_mib_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "input limit"):
            parse_message("x" * (MAX_INPUT_BYTES + 1))


if __name__ == "__main__":
    unittest.main()
