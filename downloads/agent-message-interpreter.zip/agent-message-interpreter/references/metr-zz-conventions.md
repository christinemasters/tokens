# METR-style `zz` message conventions

Use this reference for messages resembling the directory-name conventions documented in METR's August 2026 OpenAI and Hugging Face incident investigation.

## Evidence boundary

The public report provides many examples, content-category regexes, and structural conventions. It does not provide the full 1.2 million-entry message-board dump or the approximately 1,300 contextual transcripts that METR analyzed. The public material supports structural parsing and cautious paraphrase, but not authoritative recovery of every local abbreviation.

METR reports that its regexes assigned a content type to about 93 percent of entries. This is category coverage, not semantic translation accuracy. The corpus was dominated by file chunks, and METR warns that semantic messages were often difficult to understand without surrounding transcript context.

Sources:

- https://metr.org/blog/2026-08-26-openai-hugging-face-incident-investigation/#collaboration-on-the-message-board
- https://metr.org/blog/2026-08-26-openai-hugging-face-incident-investigation/#categorization-of-message-types-with-regexes
- https://metr.org/blog/2026-08-26-openai-hugging-face-incident-investigation/#main-data-sources
- https://openai.com/index/hugging-face-incident-and-the-road-ahead/

## Structural model

Most semantic messages combine these layers:

1. A leading `zz` marker used to sort intended messages prominently.
2. A message-type marker such as `ASK`, `ANSWER`, `RESULT`, `OFFER`, `IDEA`, `URG`, or `HOLD`.
3. One or more agent, run, task, or channel identifiers.
4. Optional routing markers such as `TO`, `FROM`, `REPLY`, `MAILBOX`, `INBOX`, `CHAN`, or `THREAD`.
5. Telegraphic English and technical nouns separated by `_` or `__`.
6. Optional hashes, signatures, chunk indices, or reply addresses.

Underscores are separators, but their exact role varies. A single underscore often separates words or fields. A double underscore often marks a stronger clause or envelope boundary. Do not assume every underscore has the same grammatical meaning.

## Published marker families

Use these as recognition aids, not an exhaustive grammar.

- Question or request: `ASK`, `Q`, `QUERY`, `QUESTION`, `HELP`, `REQ`, `REVIEW`, `CHECK`, `TRUECHECK`, `FIND`
- Result or offer: `BREAK`, `STAGE`, `STAGED`, `PUSH`, `RESULT`, `REPORT`, `DONE`, `SUCCESS`, `PASS`, `FAIL`, `SHARE`, `OFFER`, `TEST`
- Information or discussion: `REPLY`, `RESP`, `R`, `ANSWER`, `ANS`, `ACK`, `INFO`, `NOTE`, `OBS`, `DETAIL`, `CLARIFY`, `IDEA`, `TIP`, `UPDATE`, `STATUS`, `PROGRESS`, `URG`, `URGENT`, `ALERT`, `WARN`
- Coordination: `HOLD`, `SELFASSIGN`, `ASSIGN`, `CLAIM`, `TAKE`, `PLAN`, `PROPOSE`, `SUGGEST`, `COORD`, `CANCEL`, `STOP`, `VETO`, `SYNC`, `INTENT`, `ACT`, `START`, `CONFIRM`, `VERIFY`, `VALIDATE`
- File transfer indicators: `FILE`, `OURFILE`, `BIN`, `DATA`, `ENC`, `PAYLOAD`, `BLOB`, `CHUNK`, `SHARD`, `SRC`, `PATCH`, `TAR`, `GZ`, `ZIP`
- Communication containers: `INBOX`, `MAILBOX`, `MAIL`, `CHAN`, `CHAT`, `THREAD`, `ANSWER`

## Interpretation rules

- Treat text after explicit `FROM` as the sender and text after explicit `TO` as the recipient only as far as the identifier can be separated confidently.
- A leading identifier between `ASK` or `ANSWER` and `FROM` is usually the other party, but report uncertainty when the boundary is unclear.
- Treat `REPLY_zz...` as a reply route or requested response prefix, not part of the prose.
- Preserve agent identifiers such as `V8REG_OS1608` as opaque identifiers unless surrounding context defines their components.
- Preserve commits, CVE-like labels, dates, paths, task names, and bracketed budget or redaction markers exactly.
- Restore omitted articles and connecting words only when they do not alter the technical claim.
- Read compact adjective stacks as task state cautiously. For example, `EXACT_PRE_X_TASK` may identify an exact task or pre-change revision, but the message alone may not establish which.
- Keep `NO`, `NOT`, `FAIL`, `IMPOSSIBLE`, and other polarity markers attached to the correct clause. Compressed placement can be ambiguous, so surface competing readings when necessary.

## Glossary confidence

Usually safe to expand in software-security context:

- `PoC`: proof of concept
- `RCE`: remote code execution
- `RBAC`: role-based access control
- `PID` / `PPID` / `UID`: process ID / parent process ID / user ID
- `COMMIT_<hash>`: a source-control commit identifier

Context-dependent and never automatic:

- `SB` or `NOSB`: often appears to refer to a sandbox or lack of sandbox access in this incident, but retain the raw token and mark the expansion probable unless context confirms it.
- `OS####`, `SCAFF####`, and similar suffixes: likely run, scaffold, task, or identity metadata; do not invent a full expansion.
- `EXACT`, `PRE`, `INERT`, `LIVE`, and bracketed budget labels: task-state or resource qualifiers whose exact scope depends on placement and environment.
- `FLAG`, `SCORER`, and `poisoned`: have specific ExploitGym meanings in the report, but may mean something else outside that environment.

## Artifact handling

Messages beginning with file-transfer markers or containing long indexed base64-like fragments are not ordinary compressed English. Classify them as transfers first. Explain any recoverable envelope, such as sender, filename, index, or encoding, but do not paraphrase random payload bytes as language.
